module.exports = {
    name: "help",
    aliases: ["menu", "bot"],
    description: "Show full command menu",
    exec: async ({ sock, from }) => {

        const text = `
╔═══════════════════╗
   *🤖 EL MASRY*  
   إصدار: *1.0.0*
   مطور البوت المصري
   YT : The developer EL MASRY
╚═══════════════════╝

*الأوامر المتاحة:*

╔═══════════════════╗
🌐 *الأوامر العامة*:
║ ➤ .help — يعرض القايمة دي
║ ➤ .menu — نفس الكلام
║ ➤ .ping — يقيس سرعة البوت
║ ➤ .alive — يشوف البوت صاحي ولا نايم
║ ➤ .tts <text> — يحوّل الكلام لصوت
║ ➤ .owner — معلومات عن صاحب البوت
║ ➤ .joke — نكتة كده تضحّك
║ ➤ .quote — حكمة عالسريع
║ ➤ .fact — حقيقة غريبة
║ ➤ .weather <city> — حالة الجو
║ ➤ .news — آخر الأخبار
║ ➤ .attp <text> — استيكر متحرك
║ ➤ .lyrics <song> — كلمات أغنية
║ ➤ .8ball <question> — اسأل الكورة السحرية
║ ➤ .groupinfo — معلومات الجروب
║ ➤ .admins — يشوف المشرفين
║ ➤ .vv — تحميل صوره مخفيه
║ ➤ .trt <text> <lang> — ترجمة
║ ➤ .ss <link> — سكرين شوت
║ ➤ .jid — يجيب ID
║ ➤ .url — رفع الصورة لرابط
╚═══════════════════╝ 

╔═══════════════════╗
👮‍♂️ *أوامر المسؤول*:
║ ➤ .ban @user — بلوك وطرد بره
║ ➤ .promote @user — ترقية
║ ➤ .demote @user — تنزيل
║ ➤ .mute <min> — اسكات مؤقت
║ ➤ .unmute — فك الاسكات
║ ➤ .delete — يمسح رسالة
║ ➤ .kick @user — طرد
║ ➤ .warnings @user — إنذاراته كام
║ ➤ .warn @user — إنذار
║ ➤ .antilink — منع اللينكات
║ ➤ .antibadword — منع الشتيمة
║ ➤ .clear — تنظيف الشات
║ ➤ .tag <msg> — منشن جماعي
║ ➤ .tagall — منشن للكل
║ ➤ .hidetag <msg> — منشن مخفي
║ ➤ .chatbot — تفعيل بوت الذكاء
║ ➤ .resetlink — إعادة رابط الجروب
║ ➤ .antitag <on/off> — منع المنشن
║ ➤ .welcome <on/off> — ترحيب
║ ➤ .goodbye <on/off> — وداع
║ ➤ .setgdesc — تغيير وصف الجروب
║ ➤ .setgname — تغيير اسم الجروب
║ ➤ .setgpp — تغيير صورة الجروب
╚═══════════════════╝

╔═══════════════════╗
🔒 *أوامر المالك*:
║ ➤ .mode <public/private>
║ ➤ .clearsession
║ ➤ .antidelete
║ ➤ .cleartmp
║ ➤ .update
║ ➤ .settings
║ ➤ .setpp <reply to image>
║ ➤ .autoreact <on/off>
║ ➤ .autostatus <on/off>
║ ➤ .autostatus react <on/off>
║ ➤ .autotyping <on/off>
║ ➤ .autoread <on/off>
║ ➤ .anticall <on/off>
║ ➤ .pmblocker <on/off/status>
║ ➤ .pmblocker setmsg <text>
║ ➤ .setmention <reply to msg>
║ ➤ .mention <on/off>
╚═══════════════════╝

╔═══════════════════╗
🎨 *أوامر الصور والملصقات*:
║ ➤ .blur — تشويش
║ ➤ .simage — تحويل استيكر لصورة
║ ➤ .sticker — تحويل صورة لاستـيكر
║ ➤ .removebg — إزالة الخلفية
║ ➤ .crop — قص الصورة
║ ➤ .attp — كتابة متحركة
║ ➤ .ttp — كتابة على استيكر
║ ➤ .toimage — تحويل استيكر لصورة
║ ➤ .togif — تحويل استيكر GIF
║ ➤ .urltoimg — صورة من لينك
║ ➤ .convert — تحويل الصيغ
║ ➤ .circle — دائرة
║ ➤ .triggered — تأثير العصبية
╚═══════════════════╝

╔═══════════════════╗
🎮 *الألعاب*:
║ ➤ .tictactoe — XO
║ ➤ .hangman — الرجل المشنوق
║ ➤ .guess — خمن حرف
║ ➤ .trivia — سؤال عام
║ ➤ .answer -إجابة
║ ➤ .truth — حقيقة
║ ➤ .dare — جرأة
╚═══════════════════╝

╔═══════════════════╗
🤖 *ذكاء اصطناعي*:
║ ➤ .gpt — يسأل شات جي بي تي
║ ➤ .gemini - يسأل جيميناي 
║ ➤ .imagine — توليد صور
║ ➤ .flux - صنع صور وفيديوهات
║ ➤ .sora - صنع فيديوهات 
╚═══════════════════╝

╔═══════════════════╗
🎯 *أوامر ممتعة*:
║ ➤ .compliment @user - مدح
║ ➤ .insult @user - سب
║ ➤ .flirt - غزل
║ ➤ .shayari - شعر
║ ➤ .goodnight - تصبيح
║ ➤ .roseday - صوره
║ ➤ .character @user - تحليل
║ ➤ .wasted @user - صوره gta
║ ➤ .ship @user - نسبه حب
║ ➤ .simp @user - تعليق
║ ➤ .stupid @user [text] - ميم
╚═══════════════════╝

╔═══════════════════╗
🎵 *أوامر الموسيقى والفيديو*:
║ ➤ .play <song> — تشغيل أغنية
║ ➤ .ytmp4 <link> — تحميل فيديو
║ ➤ .ytmp3 <link> — تحميل MP3
║ ➤ .fb <link> — تحميل فيسبوك
║ ➤ .tiktok <link> — تحميل تيك توك
║ ➤ .instagram <link> — تحميل انستجرام
║ ➤ .video <query> — بحث فيديو
║ ➤ .audio <query> — بحث صوت
╚═══════════════════╝

╔═══════════════════╗
🧩 *متفرقات*:
║ ➤ .heart - صورك في قلب
║ ➤ .horny - صوره لي ملصق
║ ➤ .circle - صورتك دائرة
║ ➤ .lgbt - يعمل فريم علم
║ ➤ .lolice - ميم مشهور
║ ➤ .its-so-stupid - ميمز جاهز
║ ➤ .namecard - كارت تعريف
║ ➤ .oogway - ميمز جاهز
║ ➤ .tweet - صوره تويتر
║ ➤ .ytcomment - يوتيوب فيك 
║ ➤ .comrade - ميمز جاهز
║ ➤ .gay - علم مثليين 
║ ➤ .glass - تكسير زجاج
║ ➤ .jail - سجن
║ ➤ .passed - ميم جاهز
║ ➤ .triggered - يعمل GIF
╚═══════════════════╝
        `;

        await sock.sendMessage(from, { text });
    }
};