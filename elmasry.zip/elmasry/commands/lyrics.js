module.exports = {
  name: 'lyrics',
  aliases: [],
  description: "Executes lyrics",
  exec: async ({ sock, from, args, msg }) => {
    await sock.sendMessage(from, { text: '✅ تم تنفيذ الأمر lyrics (واضح)'});
  }
};
