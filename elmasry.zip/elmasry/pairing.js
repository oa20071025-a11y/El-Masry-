import makeWASocket, {
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
} from "@whiskeysockets/baileys"

async function startPairing() {
    console.log("\n📡 Starting Pairing System...")

    const { state, saveCreds } = await useMultiFileAuthState("./auth_info")
    const { version } = await fetchLatestBaileysVersion()

    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: false,
        browser: ["Ubuntu", "Chrome", "22.04"]
    })

    sock.ev.on("connection.update", async (update) => {
        const { connection, pairingCode } = update

        if (pairingCode) {
            console.log("\n====================================")
            console.log("📌 ادخل الكود ده في واتساب (الأجهزة المرتبطة):")
            console.log(`🔗 Pairing Code: ${pairingCode}`)
            console.log("====================================\n")
        }

        if (connection === "open") {
            console.log("✅ تم الربط بنجاح! شغّل البوت الآن بـ:")
            console.log("➡️ node index.js\n")
            process.exit()
        }

        if (connection === "close") {
            console.log("❌ الاتصال اتقفل — إعادة المحاولة…")
            startPairing()
        }
    })

    sock.ev.on("creds.update", saveCreds)

    // طلب كود الربط مباشرة
    setTimeout(async () => {
        const code = await sock.requestPairingCode("201013815156")
        console.log("🔢 Pairing Code Generated:", code)
    }, 1500)
}

startPairing()